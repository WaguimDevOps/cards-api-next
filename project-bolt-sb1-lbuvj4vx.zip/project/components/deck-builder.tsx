"use client"

import { useState, useEffect } from 'react';
import { Card } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Image from 'next/image';
import { Loader2, ArrowLeft, Save, Trash2 } from 'lucide-react';
import Link from 'next/link';
import { isExtraDeckCard, getDeckStats } from '@/lib/deck-utils';

export function DeckBuilder() {
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [cards, setCards] = useState<Card[]>([]);
  const [mainDeck, setMainDeck] = useState<Card[]>([]);
  const [extraDeck, setExtraDeck] = useState<Card[]>([]);
  const [selectedCard, setSelectedCard] = useState<Card | null>(null);
  const [limitedCards, setLimitedCards] = useState<string[]>([]);
  const [semiLimitedCards, setSemiLimitedCards] = useState<string[]>([]);
  const [forbiddenCards, setForbiddenCards] = useState<string[]>([]);
  const [page, setPage] = useState(1);
  const [totalCards, setTotalCards] = useState(0);
  const [filters, setFilters] = useState({
    type: 'all',
    attribute: 'all',
    level: 'all',
    race: 'all',
  });
  const [deckName, setDeckName] = useState('');
  const [deckDescription, setDeckDescription] = useState('');

  useEffect(() => {
    loadBanlist();
    checkForDeckToEdit();
  }, []);

  const loadBanlist = async () => {
    try {
      const response = await fetch('https://db.ygoprodeck.com/api/v7/cardinfo.php?banlist=tcg');
      const data = await response.json();
      
      if (data && data.data) {
        const limited: string[] = [];
        const semiLimited: string[] = [];
        const forbidden: string[] = [];
        
        data.data.forEach((card: Card) => {
          if (card.banlist_info && card.banlist_info.ban_tcg) {
            switch (card.banlist_info.ban_tcg) {
              case 'Limited':
                limited.push(card.id.toString());
                break;
              case 'Semi-Limited':
                semiLimited.push(card.id.toString());
                break;
              case 'Forbidden':
                forbidden.push(card.id.toString());
                break;
            }
          }
        });
        
        setLimitedCards(limited);
        setSemiLimitedCards(semiLimited);
        setForbiddenCards(forbidden);
      }
    } catch (error) {
      console.error('Error loading banlist:', error);
    }
  };

  const checkForDeckToEdit = () => {
    const deckToEditId = typeof window !== 'undefined' ? localStorage.getItem('deck_to_edit') : null;
    
    if (deckToEditId) {
      try {
        const savedDecks = JSON.parse(localStorage.getItem('yugioh_decks') || '[]');
        const deckToEdit = savedDecks.find((deck: any) => deck.id === deckToEditId);
        
        if (deckToEdit) {
          setDeckName(deckToEdit.name || '');
          setDeckDescription(deckToEdit.description || '');
          
          const mainCards = deckToEdit.cards.filter((card: Card) => !isExtraDeckCard(card));
          const extraCards = deckToEdit.cards.filter((card: Card) => isExtraDeckCard(card));
          
          setMainDeck(mainCards);
          setExtraDeck(extraCards);
        }
      } catch (error) {
        console.error('Error loading deck to edit:', error);
      }
    }
  };

  const getCardLimit = (cardId: string) => {
    if (forbiddenCards.includes(cardId)) {
      return 0;
    } else if (limitedCards.includes(cardId)) {
      return 1;
    } else if (semiLimitedCards.includes(cardId)) {
      return 2;
    } else {
      return 3;
    }
  };

  const countCardCopies = (cardName: string) => {
    const mainDeckCopies = mainDeck.filter(card => card.name === cardName).length;
    const extraDeckCopies = extraDeck.filter(card => card.name === cardName).length;
    return mainDeckCopies + extraDeckCopies;
  };

  const searchCards = async () => {
    setLoading(true);
    
    try {
      let url = 'https://db.ygoprodeck.com/api/v7/cardinfo.php?';
      
      // Add pagination
      url += `num=20&offset=${(page - 1) * 20}`;
      
      // Add search term if present
      if (searchTerm) {
        url += `&fname=${encodeURIComponent(searchTerm)}`;
      }
      
      // Add filters if present
      if (filters.type !== 'all') {
        url += `&type=${encodeURIComponent(filters.type)}`;
      }
      
      if (filters.attribute !== 'all') {
        url += `&attribute=${encodeURIComponent(filters.attribute)}`;
      }
      
      if (filters.level !== 'all') {
        url += `&level=${encodeURIComponent(filters.level)}`;
      }
      
      if (filters.race !== 'all') {
        url += `&race=${encodeURIComponent(filters.race)}`;
      }
      
      const response = await fetch(url);
      const data = await response.json();
      
      setCards(data.data || []);
      setTotalCards(data.meta?.total_rows || 0);
    } catch (error) {
      console.error('Error fetching cards:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    searchCards();
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setPage(1);
  };

  const addCardToDeck = (card: Card) => {
    // Check if card is forbidden
    const cardLimit = getCardLimit(card.id.toString());
    if (cardLimit === 0) {
      alert(`A carta "${card.name}" está proibida e não pode ser adicionada ao deck!`);
      return;
    }

    // Check if it's an Extra Deck card
    if (isExtraDeckCard(card)) {
      // Check Extra Deck limit
      if (extraDeck.length >= 15) {
        alert('O Extra Deck não pode ter mais de 15 cartas!');
        return;
      }
      
      // Check copy limit
      const copiesInDeck = countCardCopies(card.name);
      
      if (copiesInDeck >= cardLimit) {
        alert(`Você já tem ${copiesInDeck} cópias de "${card.name}" no deck! O limite para esta carta é ${cardLimit}.`);
        return;
      }
      
      setExtraDeck(prev => [...prev, card]);
    } else {
      // Check Main Deck limit
      if (mainDeck.length >= 60) {
        alert('O Main Deck não pode ter mais de 60 cartas!');
        return;
      }
      
      // Check copy limit
      const copiesInDeck = countCardCopies(card.name);
      
      if (copiesInDeck >= cardLimit) {
        alert(`Você já tem ${copiesInDeck} cópias de "${card.name}" no deck! O limite para esta carta é ${cardLimit}.`);
        return;
      }
      
      setMainDeck(prev => [...prev, card]);
    }
  };

  const removeCardFromDeck = (card: Card, isMain: boolean) => {
    if (isMain) {
      setMainDeck(prev => {
        const index = prev.findIndex(c => c.id === card.id);
        if (index >= 0) {
          const newDeck = [...prev];
          newDeck.splice(index, 1);
          return newDeck;
        }
        return prev;
      });
    } else {
      setExtraDeck(prev => {
        const index = prev.findIndex(c => c.id === card.id);
        if (index >= 0) {
          const newDeck = [...prev];
          newDeck.splice(index, 1);
          return newDeck;
        }
        return prev;
      });
    }
  };

  const saveDeck = () => {
    if (mainDeck.length === 0 && extraDeck.length === 0) {
      alert('Não é possível salvar um deck vazio!');
      return;
    }
    
    if (!deckName.trim()) {
      alert('Por favor, dê um nome ao seu deck.');
      return;
    }

    // Check if we're editing an existing deck
    const deckToEditId = typeof window !== 'undefined' ? localStorage.getItem('deck_to_edit') : null;
    let deckId = deckToEditId || Date.now().toString();
    
    // Create deck object
    const deck = {
      id: deckId,
      name: deckName,
      description: deckDescription || '',
      cards: [...mainDeck, ...extraDeck],
      created_at: deckToEditId ? localStorage.getItem('deck_created') || new Date().toISOString() : new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    // If we're editing, ask if user wants to overwrite or create new
    if (deckToEditId && !confirm('Deseja sobrescrever o deck existente?')) {
      // Create new deck
      deck.id = Date.now().toString();
      deck.created_at = new Date().toISOString();
    }
    
    // Save to localStorage
    const savedDecks = JSON.parse(localStorage.getItem('yugioh_decks') || '[]');
    
    // Check if a deck with this ID already exists
    const existingDeckIndex = savedDecks.findIndex((d: any) => d.id === deck.id);
    
    if (existingDeckIndex >= 0) {
      // Update existing deck
      savedDecks[existingDeckIndex] = deck;
    } else {
      // Add new deck
      savedDecks.push(deck);
    }
    
    localStorage.setItem('yugioh_decks', JSON.stringify(savedDecks));
    
    // Clear edit flag
    localStorage.removeItem('deck_to_edit');
    localStorage.removeItem('deck_name');
    localStorage.removeItem('deck_description');
    localStorage.removeItem('deck_created');
    
    alert('Deck salvo com sucesso!');
    
    // Ask if user wants to go back to decks page
    if (confirm('Deseja voltar para a página de decks?')) {
      window.location.href = '/my-decks';
    }
  };

  const clearDeck = () => {
    if (confirm('Tem certeza que deseja limpar o deck?')) {
      setMainDeck([]);
      setExtraDeck([]);
    }
  };

  const stats = getDeckStats(mainDeck, extraDeck);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button asChild variant="outline" size="icon">
            <Link href="/my-decks">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">Deck Builder</h1>
        </div>
        
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            onClick={clearDeck}
            className="gap-2"
          >
            <Trash2 className="h-4 w-4" />
            Limpar
          </Button>
          <Button 
            onClick={saveDeck}
            className="gap-2"
          >
            <Save className="h-4 w-4" />
            Salvar
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Card info panel */}
        <div className="rounded-lg border bg-card p-4">
          <Tabs defaultValue="info">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="info">Carta</TabsTrigger>
              <TabsTrigger value="deck">Deck</TabsTrigger>
            </TabsList>
            
            <TabsContent value="info" className="space-y-4">
              <div className="flex justify-center">
                <div className="relative w-full max-w-[240px] aspect-[3/4.4]">
                  <Image
                    src={selectedCard?.card_images?.[0]?.image_url || "https://images.ygoprodeck.com/images/cards/back_card.jpg"}
                    alt={selectedCard?.name || "Card Back"}
                    fill
                    className="object-contain"
                    sizes="(max-width: 768px) 100vw, 240px"
                    priority
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-xl font-semibold">{selectedCard?.name || "Selecione uma carta"}</h3>
                
                {selectedCard ? (
                  <div className="space-y-2 text-sm">
                    <p><strong>Tipo:</strong> {selectedCard.type}</p>
                    
                    {selectedCard.attribute && (
                      <p><strong>Atributo:</strong> {selectedCard.attribute}</p>
                    )}
                    
                    {selectedCard.level && (
                      <p><strong>Nível:</strong> {selectedCard.level}</p>
                    )}
                    
                    {selectedCard.race && (
                      <p><strong>Tipo:</strong> {selectedCard.race}</p>
                    )}
                    
                    {selectedCard.atk !== undefined && (
                      <p>
                        <strong>ATK/DEF:</strong> {selectedCard.atk} / {selectedCard.def !== undefined ? selectedCard.def : '?'}
                      </p>
                    )}
                    
                    <p><strong>Descrição:</strong></p>
                    <p className="text-muted-foreground">{selectedCard.desc}</p>
                  </div>
                ) : (
                  <p className="text-muted-foreground">Clique em uma carta para ver seus detalhes.</p>
                )}
              </div>
              
              {selectedCard && (
                <Button 
                  className="w-full" 
                  onClick={() => addCardToDeck(selectedCard)}
                >
                  Adicionar ao Deck
                </Button>
              )}
            </TabsContent>
            
            <TabsContent value="deck" className="space-y-4">
              <div className="space-y-3">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Nome do Deck</label>
                  <Input
                    value={deckName}
                    onChange={(e) => setDeckName(e.target.value)}
                    placeholder="Ex: Blue-Eyes Deck"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Descrição (opcional)</label>
                  <Input
                    value={deckDescription}
                    onChange={(e) => setDeckDescription(e.target.value)}
                    placeholder="Descrição do seu deck..."
                  />
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-3">
                <h3 className="font-semibold">Estatísticas do Deck</h3>
                
                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded bg-muted p-2">
                    <p className="text-xs text-muted-foreground">Total</p>
                    <p className="text-lg font-semibold">{stats.total}/60</p>
                  </div>
                  
                  <div className="rounded bg-muted p-2">
                    <p className="text-xs text-muted-foreground">Extra Deck</p>
                    <p className="text-lg font-semibold">{stats.extraCount}/15</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-2">
                  <div className="rounded bg-muted p-2">
                    <p className="text-xs text-muted-foreground">Monstros</p>
                    <p className="text-lg font-semibold">{stats.monsterCount}</p>
                  </div>
                  
                  <div className="rounded bg-muted p-2">
                    <p className="text-xs text-muted-foreground">Mágicas</p>
                    <p className="text-lg font-semibold">{stats.spellCount}</p>
                  </div>
                  
                  <div className="rounded bg-muted p-2">
                    <p className="text-xs text-muted-foreground">Armadilhas</p>
                    <p className="text-lg font-semibold">{stats.trapCount}</p>
                  </div>
                </div>
                
                {stats.total < 40 && (
                  <p className="text-amber-500 text-sm">
                    Um deck deve ter no mínimo 40 cartas no Main Deck.
                  </p>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        {/* Card search & pool panel */}
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-xl font-semibold mb-3">Buscar Cartas</h2>
          
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="flex gap-2">
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Nome da carta..."
                className="flex-1"
              />
              <Button type="submit" disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Buscar'}
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Select
                  value={filters.type}
                  onValueChange={(value) => handleFilterChange('type', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Tipos</SelectItem>
                    <SelectItem value="Effect Monster">Monstro de Efeito</SelectItem>
                    <SelectItem value="Normal Monster">Monstro Normal</SelectItem>
                    <SelectItem value="Fusion Monster">Monstro de Fusão</SelectItem>
                    <SelectItem value="Synchro Monster">Monstro Sincro</SelectItem>
                    <SelectItem value="XYZ Monster">Monstro XYZ</SelectItem>
                    <SelectItem value="Link Monster">Monstro Link</SelectItem>
                    <SelectItem value="Spell Car">Carta Mágica</SelectItem>
                    <SelectItem value="Trap Card">Carta Armadilha</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Select
                  value={filters.attribute}
                  onValueChange={(value) => handleFilterChange('attribute', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Atributo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Atributos</SelectItem>
                    <SelectItem value="DARK">DARK</SelectItem>
                    <SelectItem value="LIGHT">LIGHT</SelectItem>
                    <SelectItem value="EARTH">EARTH</SelectItem>
                    <SelectItem value="WATER">WATER</SelectItem>
                    <SelectItem value="FIRE">FIRE</SelectItem>
                    <SelectItem value="WIND">WIND</SelectItem>
                    <SelectItem value="DIVINE">DIVINE</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </form>
          
          <div className="mt-3 flex items-center justify-between text-sm">
            <span className="text-muted-foreground">
              {totalCards > 0 ? `${totalCards} cartas encontradas` : 'Busque cartas...'}
            </span>
            
            {totalCards > 0 && (
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (page > 1) {
                      setPage(p => p - 1);
                      searchCards();
                    }
                  }}
                  disabled={page === 1 || loading}
                >
                  Anterior
                </Button>
                <span>
                  Página {page}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setPage(p => p + 1);
                    searchCards();
                  }}
                  disabled={page * 20 >= totalCards || loading}
                >
                  Próxima
                </Button>
              </div>
            )}
          </div>
          
          {loading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : cards.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2 mt-4 pb-4 max-h-[500px] overflow-y-auto">
              {cards.map((card) => {
                const cardLimit = getCardLimit(card.id.toString());
                const copiesInDeck = countCardCopies(card.name);
                const remainingCopies = cardLimit - copiesInDeck;
                
                return (
                  <div
                    key={card.id}
                    className={`relative cursor-pointer border rounded overflow-hidden transition-all hover:ring-2 hover:ring-primary ${
                      cardLimit === 0 
                        ? 'opacity-40' 
                        : remainingCopies <= 0 
                          ? 'opacity-60' 
                          : ''
                    }`}
                    onClick={() => setSelectedCard(card)}
                    onDoubleClick={() => {
                      if (cardLimit > 0 && remainingCopies > 0) {
                        addCardToDeck(card);
                      }
                    }}
                  >
                    <div className="aspect-[3/4.4] relative">
                      <Image
                        src={card.card_images[0].image_url_small || card.card_images[0].image_url}
                        alt={card.name}
                        fill
                        sizes="(max-width: 768px) 25vw, 16vw"
                        className="object-cover"
                      />
                      
                      {cardLimit === 0 && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-xl">🚫</span>
                        </div>
                      )}
                      
                      <div className={`absolute bottom-1 right-1 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold ${
                        cardLimit === 0 
                          ? 'bg-red-600 text-white' 
                          : remainingCopies <= 0 
                            ? 'bg-amber-600 text-white' 
                            : 'bg-green-600 text-white'
                      }`}>
                        {cardLimit === 0 ? 'X' : remainingCopies}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8">
              <p className="text-muted-foreground text-center">
                Busque cartas para adicionar ao seu deck.
              </p>
            </div>
          )}
        </div>
        
        {/* Deck panel */}
        <div className="rounded-lg border bg-card p-4">
          <Tabs defaultValue="main">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="main">Main Deck ({mainDeck.length})</TabsTrigger>
              <TabsTrigger value="extra">Extra Deck ({extraDeck.length})</TabsTrigger>
            </TabsList>
            
            <TabsContent value="main">
              {mainDeck.length > 0 ? (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-3 lg:grid-cols-4 gap-2 pb-4 max-h-[600px] overflow-y-auto">
                  {mainDeck.map((card, index) => (
                    <div
                      key={`main-${card.id}-${index}`}
                      className="relative cursor-pointer border rounded overflow-hidden transition-all hover:ring-2 hover:ring-primary"
                      onClick={() => setSelectedCard(card)}
                      onDoubleClick={() => removeCardFromDeck(card, true)}
                    >
                      <div className="aspect-[3/4.4] relative">
                        <Image
                          src={card.card_images[0].image_url_small || card.card_images[0].image_url}
                          alt={card.name}
                          fill
                          sizes="(max-width: 768px) 25vw, 16vw"
                          className="object-cover"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8">
                  <p className="text-muted-foreground text-center">
                    Seu main deck está vazio. Adicione cartas a partir da busca.
                  </p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="extra">
              {extraDeck.length > 0 ? (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-3 lg:grid-cols-4 gap-2 pb-4 max-h-[600px] overflow-y-auto">
                  {extraDeck.map((card, index) => (
                    <div
                      key={`extra-${card.id}-${index}`}
                      className="relative cursor-pointer border rounded overflow-hidden transition-all hover:ring-2 hover:ring-primary"
                      onClick={() => setSelectedCard(card)}
                      onDoubleClick={() => removeCardFromDeck(card, false)}
                    >
                      <div className="aspect-[3/4.4] relative">
                        <Image
                          src={card.card_images[0].image_url_small || card.card_images[0].image_url}
                          alt={card.name}
                          fill
                          sizes="(max-width: 768px) 25vw, 16vw"
                          className="object-cover"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8">
                  <p className="text-muted-foreground text-center">
                    Seu extra deck está vazio. Adicione cartas a partir da busca.
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}